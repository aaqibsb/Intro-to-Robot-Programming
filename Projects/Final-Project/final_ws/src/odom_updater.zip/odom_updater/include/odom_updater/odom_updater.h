#pragma once

#include <sstream>
#include <string>


#include "geometry_msgs/msg/transform_stamped.hpp"
#include "rclcpp/rclcpp.hpp"
#include "tf2/LinearMath/Quaternion.h"
#include "tf2_ros/transform_broadcaster.h"
#include <nav_msgs/msg/odometry.hpp>


class FramePublisher : public rclcpp::Node
{
public:
  FramePublisher()
  : Node("odom_updater")
  {
    // Initialize the transform broadcaster
    tf_broadcaster = std::make_unique<tf2_ros::TransformBroadcaster>(this);


    // Subscribe to a /robot1/odom topic and call timer_callback
    tf_subscription = this->create_subscription<nav_msgs::msg::Odometry>("/robot1/odom", 10, std::bind(&FramePublisher::timer_callback, this, std::placeholders::_1));
  }

private:
  void timer_callback(const std::shared_ptr<nav_msgs::msg::Odometry> msg);
  
    rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr tf_subscription;
    std::unique_ptr<tf2_ros::TransformBroadcaster> tf_broadcaster;
};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<FramePublisher>());
  rclcpp::shutdown();
  return 0;
}
